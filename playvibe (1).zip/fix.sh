#!/bin/bash
sed -i 's/val videoPicker/val context = androidx.compose.ui.platform.LocalContext.current\n    val videoPicker/' app/src/main/java/com/example/UploadScreen.kt
sed -i 's/retriever.setDataSource(androidx.compose.ui.platform.LocalContext.current, uri)/retriever.setDataSource(context, uri)/' app/src/main/java/com/example/UploadScreen.kt
