package com.example

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UploadScreen(onDismiss: () -> Unit) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Music") }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var isUploading by remember { mutableStateOf(false) }
    var uploadProgress by remember { mutableStateOf(0f) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()
    
    val context = androidx.compose.ui.platform.LocalContext.current
    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val retriever = android.media.MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, uri)
                val time = retriever.extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_DURATION)
                val timeInMillis = time?.toLongOrNull() ?: 0L
                if (timeInMillis > 15 * 60 * 1000) {
                    errorMessage = "Video must be under 15 minutes"
                    videoUri = null
                } else {
                    errorMessage = null
                    videoUri = uri
                }
            } catch (e: Exception) {
                errorMessage = "Invalid video file"
            } finally {
                retriever.release()
            }
        } else {
            videoUri = null
        }
    }
    
    Scaffold(
        topBar = {
            TopAppBar(title = { Text("Upload Video") })
        }
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(8.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                label = { Text("Description") },
                modifier = Modifier.fillMaxWidth(),
                minLines = 3
            )
            Spacer(modifier = Modifier.height(8.dp))
            
            Button(onClick = { videoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) }, modifier = Modifier.fillMaxWidth()) {
                Text(if (videoUri != null) "Video Selected ✓" else "Select Video")
            }
            
            if (errorMessage != null) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(errorMessage!!, color = MaterialTheme.colorScheme.error)
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            if (isUploading) {
                LinearProgressIndicator(
                    progress = { uploadProgress },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("Uploading... ${(uploadProgress * 100).toInt()}%", modifier = Modifier.align(Alignment.CenterHorizontally))
                Spacer(modifier = Modifier.height(16.dp))
            }
            
            Button(
                onClick = {
                    if (videoUri == null) {
                        errorMessage = "Please select a video"
                        return@Button
                    }
                    if (title.isBlank()) {
                        errorMessage = "Please enter a title"
                        return@Button
                    }
                    scope.launch {
                        isUploading = true
                        errorMessage = null
                        try {
                            val user = FirebaseManager.auth.currentUser ?: throw Exception("Not authenticated")
                            val videoId = java.util.UUID.randomUUID().toString()
                            val videoRef = FirebaseManager.storage.reference.child("videos/$videoId.mp4")
                            
                            val uploadTask = videoRef.putFile(videoUri!!)
                            uploadTask.addOnProgressListener { taskSnapshot ->
                                val progress = (100.0 * taskSnapshot.bytesTransferred) / taskSnapshot.totalByteCount
                                uploadProgress = (progress / 100f).toFloat()
                            }
                            
                            uploadTask.await()
                            val downloadUrl = videoRef.downloadUrl.await().toString()
                            
                            val videoData = mapOf(
                                "id" to videoId,
                                "title" to title,
                                "description" to description,
                                "uploaderChannelId" to user.uid,
                                "thumbnailUrl" to "https://picsum.photos/seed/$videoId/600/300",
                                "videoUrl" to downloadUrl,
                                "viewCount" to "0",
                                "likeCount" to 0,
                                "category" to category,
                                "viralScore" to 0,
                                "uploadDate" to System.currentTimeMillis().toString(),
                                "isCopyrightClaimed" to false
                            )
                            FirebaseManager.firestore.collection("videos").document(videoId).set(videoData).await()
                            android.widget.Toast.makeText(context, "Upload successful!", android.widget.Toast.LENGTH_LONG).show()
                            onDismiss()
                        } catch (e: Exception) {
                            errorMessage = e.message
                            isUploading = false
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = !isUploading && videoUri != null && title.isNotBlank()
            ) {
                Text("Upload")
            }
        }
    }
}
