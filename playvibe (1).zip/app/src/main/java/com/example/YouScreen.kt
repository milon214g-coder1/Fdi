package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.PlaylistPlay
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.WatchLater
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

import androidx.compose.foundation.clickable

@Composable
fun YouScreen(
    onChannelClick: (String) -> Unit,
    onHistoryClick: () -> Unit,
    onPlaylistsClick: () -> Unit,
    onWatchLaterClick: () -> Unit,
    onLikedVideosClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    LazyColumn(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        item {
            // Profile Info
            Row(
                verticalAlignment = Alignment.CenterVertically, 
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onChannelClick(currentUserChannel.id) }
                    .padding(bottom = 24.dp)
            ) {
                AsyncImage(
                    model = currentUserChannel.profileImageUrl,
                    contentDescription = "My Profile",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(80.dp).clip(CircleShape)
                )
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(currentUserChannel.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text("@${currentUserChannel.name.lowercase()} • ${currentUserChannel.vibersCount} Vibers", fontSize = 14.sp, color = androidx.compose.material3.MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                }
            }
            
            Divider()
            Spacer(modifier = Modifier.height(16.dp))
            
            // Menu Items
            LibraryItem(icon = Icons.Filled.History, label = "History", onClick = onHistoryClick)
            LibraryItem(icon = Icons.Filled.PlaylistPlay, label = "Playlists", onClick = onPlaylistsClick)
            LibraryItem(icon = Icons.Filled.WatchLater, label = "Watch Later", onClick = onWatchLaterClick)
            LibraryItem(icon = Icons.Filled.ThumbUp, label = "Liked Videos", onClick = onLikedVideosClick)
            
            Spacer(modifier = Modifier.height(16.dp))
            Divider()
            Spacer(modifier = Modifier.height(16.dp))
            
            LibraryItem(icon = Icons.Filled.Settings, label = "Settings", onClick = onSettingsClick)
        }
    }
}

@Composable
fun LibraryItem(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, contentDescription = label, modifier = Modifier.size(28.dp))
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = label, fontSize = 16.sp)
    }
}
