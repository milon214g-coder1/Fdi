package com.example

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SoundDetailsScreen(soundId: String, onNavigateUp: () -> Unit, onVideoClick: (String) -> Unit) {
    val sound = mockSounds.find { it.id == soundId }
    val relatedVideos = mockVideos.filter { it.soundId == soundId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Sound") },
                navigationIcon = {
                    IconButton(onClick = onNavigateUp) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (sound != null) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.MusicNote,
                        contentDescription = "Sound Icon",
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(text = sound.name, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Original Creator: ${sound.originalChannelName}", fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(text = "${relatedVideos.size} videos using this sound", fontSize = 14.sp)
                    }
                }
                
                Divider()
                
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(relatedVideos) { video ->
                        VideoCard(video = video, onClick = { onVideoClick(video.id) })
                    }
                }
            } else {
                Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Sound not found")
                }
            }
        }
    }
}
